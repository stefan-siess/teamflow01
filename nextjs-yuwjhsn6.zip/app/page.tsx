'use client';

import React, { useMemo, useState } from 'react';

export default function TeamFlow() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [activePage, setActivePage] = useState('Dashboard');

  const [toast, setToast] = useState('');

  const showToast = (message: string) => {
    setToast(message);

    setTimeout(() => {
      setToast('');
    }, 3000);
  };

  // Mitarbeiter
  const [employees, setEmployees] = useState([
    {
      id: 1,
      name: 'Anna Müller',
      department: 'Büro',
      vacation: '124h',
      za: '32h',
      birthday: '14.06',
      status: 'Anwesend',
    },
    {
      id: 2,
      name: 'Max Steiner',
      department: 'Lager',
      vacation: '88h',
      za: '18h',
      birthday: '21.08',
      status: 'Anwesend',
    },
  ]);

  // Urlaubsanträge
  const [requests, setRequests] = useState([
    {
      id: 1,
      employee: 'Anna Müller',
      hours: '8h',
      date: '2026-07-10',
      status: 'Genehmigt',
    },
  ]);

  // Events
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Sommer Grillfeier 🍖',
      description: 'Gemeinsamer Abend mit Grillen & Musik',
      date: '2026-07-22',
      voteDeadline: '2026-07-15',
      participants: ['Anna Müller'],
      image: 'https://images.unsplash.com/photo-1528605248644-14dd04022da1',
    },
  ]);

  // WhatsApp
  const [whatsappGroup, setWhatsappGroup] = useState('TeamFlow Gruppe');

  const [birthdayMessage, setBirthdayMessage] = useState(
    '🎂 Alles Gute zum Geburtstag vom gesamten Team!'
  );

  // Modals
  const [showVacationModal, setShowVacationModal] = useState(false);

  const [showEmployeeModal, setShowEmployeeModal] = useState(false);

  const [showEventModal, setShowEventModal] = useState(false);

  const [editingEvent, setEditingEvent] = useState<any>(null);

  // Formulare
  const [newRequest, setNewRequest] = useState({
    employee: '',
    hours: '',
    date: '',
  });

  const [newEmployee, setNewEmployee] = useState({
    name: '',
    department: '',
    vacation: '',
    za: '',
  });

  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    date: '',
    voteDeadline: '',
    image: '',
  });

  // Dashboard Daten
  const openRequests = useMemo(
    () => requests.filter((r) => r.status === 'Offen').length,
    [requests]
  );

  // Urlaub beantragen
  const addRequest = () => {
    if (!newRequest.employee || !newRequest.date) {
      showToast('Bitte Mitarbeiter & Datum eingeben');
      return;
    }

    const request = {
      id: Date.now(),
      ...newRequest,
      status: 'Offen',
    };

    setRequests([...requests, request]);

    setShowVacationModal(false);

    setNewRequest({
      employee: '',
      hours: '',
      date: '',
    });

    showToast('Urlaubsantrag erfolgreich erstellt');
  };

  // Antrag genehmigen
  const approveRequest = (id: number) => {
    const updatedRequests = requests.map((r) =>
      r.id === id ? { ...r, status: 'Genehmigt' } : r
    );

    setRequests(updatedRequests);

    showToast('Urlaub genehmigt ✅');
  };

  // Antrag ablehnen
  const rejectRequest = (id: number) => {
    setRequests(
      requests.map((r) => (r.id === id ? { ...r, status: 'Abgelehnt' } : r))
    );

    showToast('Urlaub abgelehnt ❌');
  };

  // Mitarbeiter hinzufügen
  const addEmployee = () => {
    if (!newEmployee.name) {
      showToast('Name fehlt');
      return;
    }

    setEmployees([
      ...employees,
      {
        id: Date.now(),
        ...newEmployee,
        birthday: '-',
        status: 'Anwesend',
      },
    ]);

    setShowEmployeeModal(false);

    setNewEmployee({
      name: '',
      department: '',
      vacation: '',
      za: '',
    });

    showToast('Mitarbeiter erfolgreich erstellt');
  };

  // Event hinzufügen
  const addEvent = () => {
    if (!newEvent.title) {
      showToast('Titel fehlt');
      return;
    }

    setEvents([
      ...events,
      {
        id: Date.now(),
        ...newEvent,
        participants: [],
      },
    ]);

    setShowEventModal(false);

    setNewEvent({
      title: '',
      description: '',
      date: '',
      voteDeadline: '',
      image: '',
    });

    showToast('Event erstellt 🎉');
  };

  // Event bearbeiten
  const updateEvent = () => {
    setEvents(
      events.map((event) =>
        event.id === editingEvent.id ? editingEvent : event
      )
    );

    setEditingEvent(null);

    showToast('Event gespeichert');
  };

  // Teilnahme
  const joinEvent = (eventId: number, employeeName: string) => {
    setEvents(
      events.map((event) => {
        if (event.id === eventId) {
          const alreadyJoined = event.participants.includes(employeeName);

          return {
            ...event,
            participants: alreadyJoined
              ? event.participants
              : [...event.participants, employeeName],
          };
        }

        return event;
      })
    );

    showToast('Teilnahme gespeichert ✅');
  };

  // WhatsApp Test
  const sendWhatsAppTest = () => {
    showToast('WhatsApp Nachricht erfolgreich gesendet 💬');
  };

  // LOGIN
  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-blue-900 flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md">
          <h1 className="text-5xl font-bold text-center">TeamFlow</h1>

          <p className="text-center text-slate-500 mt-3">
            Modernes Mitarbeiterportal
          </p>

          <div className="space-y-4 mt-8">
            <input
              className="w-full border rounded-2xl px-4 py-3"
              placeholder="admin@teamflow.at"
            />

            <input
              type="password"
              className="w-full border rounded-2xl px-4 py-3"
              placeholder="Passwort"
            />

            <button
              onClick={() => setLoggedIn(true)}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl hover:bg-blue-700 transition"
            >
              Anmelden
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      {/* TOAST */}
      {toast && (
        <div className="fixed top-6 right-6 bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl z-50">
          {toast}
        </div>
      )}

      {/* SIDEBAR */}
      <aside className="w-72 bg-slate-900 text-white p-6">
        <h1 className="text-3xl font-bold">TeamFlow</h1>

        <div className="flex flex-col gap-3 mt-8">
          {[
            'Dashboard',
            'Urlaub',
            'Anträge',
            'Events',
            'Mitarbeiter',
            'WhatsApp',
          ].map((item) => (
            <button
              key={item}
              onClick={() => setActivePage(item)}
              className={`rounded-2xl px-4 py-3 text-left transition ${
                activePage === item
                  ? 'bg-blue-600'
                  : 'bg-slate-800 hover:bg-slate-700'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      </aside>

      {/* MAIN */}
      <main className="flex-1 p-8 overflow-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-4xl font-bold">{activePage}</h2>

          <div className="flex gap-3">
            <button
              onClick={() => setShowEmployeeModal(true)}
              className="bg-white px-5 py-3 rounded-2xl shadow"
            >
              + Mitarbeiter
            </button>

            <button
              onClick={() => setShowVacationModal(true)}
              className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
            >
              Urlaub beantragen
            </button>
          </div>
        </div>

        {/* DASHBOARD */}
        {activePage === 'Dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm">
              <h3 className="text-2xl font-bold">Mitarbeiter</h3>

              <p className="text-5xl mt-4">{employees.length}</p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm">
              <h3 className="text-2xl font-bold">Events</h3>

              <p className="text-5xl mt-4">{events.length}</p>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm">
              <h3 className="text-2xl font-bold">Offene Anträge</h3>

              <p className="text-5xl mt-4">{openRequests}</p>
            </div>
          </div>
        )}

        {/* URLAUB */}
        {activePage === 'Urlaub' && (
          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <h3 className="text-3xl font-bold mb-6">Urlaubskalender 📅</h3>

            <div className="grid grid-cols-7 gap-4">
              {Array.from({
                length: 31,
              }).map((_, i) => {
                const day = i + 1;

                return (
                  <div
                    key={i}
                    className="min-h-[140px] rounded-3xl border border-slate-200 bg-slate-50 p-3"
                  >
                    <div className="font-bold mb-3">{day}</div>

                    {requests.map((request) => {
                      const requestDay = Number(request.date.split('-')[2]);

                      if (
                        request.status === 'Genehmigt' &&
                        requestDay === day
                      ) {
                        return (
                          <div
                            key={request.id}
                            className="bg-blue-500 text-white text-xs rounded-xl px-3 py-2 mb-2"
                          >
                            {request.employee}
                          </div>
                        );
                      }

                      return null;
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ANTRÄGE */}
        {activePage === 'Anträge' && (
          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <h3 className="text-3xl font-bold mb-6">Urlaubsanträge</h3>

            <div className="space-y-4">
              {requests.map((request) => (
                <div
                  key={request.id}
                  className="border rounded-2xl p-4 flex justify-between items-center"
                >
                  <div>
                    <p className="font-bold">{request.employee}</p>

                    <p>
                      {request.hours} • {request.date}
                    </p>

                    <p>Status: {request.status}</p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => approveRequest(request.id)}
                      className="bg-green-500 text-white px-4 py-2 rounded-xl"
                    >
                      Genehmigen
                    </button>

                    <button
                      onClick={() => rejectRequest(request.id)}
                      className="bg-red-500 text-white px-4 py-2 rounded-xl"
                    >
                      Ablehnen
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EVENTS */}
        {activePage === 'Events' && (
          <div className="space-y-6">
            <div className="flex justify-end">
              <button
                onClick={() => setShowEventModal(true)}
                className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
              >
                Neues Event
              </button>
            </div>

            {events.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-3xl overflow-hidden shadow-sm"
              >
                {event.image && (
                  <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-64 object-cover"
                  />
                )}

                <div className="p-6">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="text-3xl font-bold">{event.title}</h3>

                      <p className="text-slate-500 mt-2">{event.description}</p>
                    </div>

                    <button
                      onClick={() => setEditingEvent(event)}
                      className="bg-blue-600 text-white px-4 py-2 rounded-xl"
                    >
                      Bearbeiten
                    </button>
                  </div>

                  <div className="mt-6 space-y-2">
                    <p>📅 {event.date}</p>

                    <p>⏳ Abstimmung bis: {event.voteDeadline}</p>

                    <p>👥 Teilnehmer: {event.participants.length}</p>
                  </div>

                  <div className="flex gap-3 mt-6">
                    <button
                      onClick={() => joinEvent(event.id, 'Anna Müller')}
                      className="bg-green-100 text-green-700 px-4 py-3 rounded-2xl"
                    >
                      ✅ Ich komme
                    </button>

                    <button className="bg-red-100 text-red-700 px-4 py-3 rounded-2xl">
                      ❌ Absagen
                    </button>

                    <button className="bg-yellow-100 text-yellow-700 px-4 py-3 rounded-2xl">
                      🤔 Vielleicht
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* MITARBEITER */}
        {activePage === 'Mitarbeiter' && (
          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <h3 className="text-3xl font-bold mb-6">Mitarbeiter</h3>

            <div className="space-y-4">
              {employees.map((employee) => (
                <div
                  key={employee.id}
                  className="border rounded-2xl p-4 flex justify-between"
                >
                  <div>
                    <p className="font-bold text-lg">{employee.name}</p>

                    <p className="text-slate-500">{employee.department}</p>

                    <p>Urlaub: {employee.vacation}</p>

                    <p>ZA: {employee.za}</p>
                  </div>

                  <div className="bg-blue-100 text-blue-700 px-4 py-2 rounded-xl h-fit">
                    {employee.status}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* WHATSAPP */}
        {activePage === 'WhatsApp' && (
          <div className="bg-white rounded-3xl p-6 shadow-sm max-w-3xl">
            <h3 className="text-3xl font-bold mb-6">WhatsApp Center 💬</h3>

            <div className="space-y-5">
              <div>
                <label className="block mb-2 font-semibold">Gruppenname</label>

                <input
                  value={whatsappGroup}
                  onChange={(e) => setWhatsappGroup(e.target.value)}
                  className="w-full border rounded-2xl px-4 py-3"
                />
              </div>

              <div>
                <label className="block mb-2 font-semibold">
                  Geburtstagsnachricht
                </label>

                <textarea
                  value={birthdayMessage}
                  onChange={(e) => setBirthdayMessage(e.target.value)}
                  rows={4}
                  className="w-full border rounded-2xl px-4 py-3"
                />
              </div>

              <button
                onClick={sendWhatsAppTest}
                className="bg-green-500 text-white px-6 py-4 rounded-2xl"
              >
                Testnachricht senden
              </button>
            </div>
          </div>
        )}

        {/* EVENT MODAL */}
        {showEventModal && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
            <div className="bg-white rounded-3xl p-8 w-full max-w-xl">
              <h3 className="text-3xl font-bold mb-6">Neues Event</h3>

              <div className="space-y-4">
                <input
                  placeholder="Titel"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEvent({
                      ...newEvent,
                      title: e.target.value,
                    })
                  }
                />

                <textarea
                  placeholder="Beschreibung"
                  rows={4}
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEvent({
                      ...newEvent,
                      description: e.target.value,
                    })
                  }
                />

                <input
                  type="date"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEvent({
                      ...newEvent,
                      date: e.target.value,
                    })
                  }
                />

                <input
                  type="date"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEvent({
                      ...newEvent,
                      voteDeadline: e.target.value,
                    })
                  }
                />

                <input
                  placeholder="Bild URL"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEvent({
                      ...newEvent,
                      image: e.target.value,
                    })
                  }
                />

                <div className="flex gap-3">
                  <button
                    onClick={addEvent}
                    className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
                  >
                    Speichern
                  </button>

                  <button
                    onClick={() => setShowEventModal(false)}
                    className="bg-slate-200 px-5 py-3 rounded-2xl"
                  >
                    Abbrechen
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* EVENT BEARBEITEN */}
        {editingEvent && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
            <div className="bg-white rounded-3xl p-8 w-full max-w-xl">
              <h3 className="text-3xl font-bold mb-6">Event bearbeiten</h3>

              <div className="space-y-4">
                <input
                  value={editingEvent.title}
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setEditingEvent({
                      ...editingEvent,
                      title: e.target.value,
                    })
                  }
                />

                <textarea
                  value={editingEvent.description}
                  rows={4}
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setEditingEvent({
                      ...editingEvent,
                      description: e.target.value,
                    })
                  }
                />

                <div className="flex gap-3">
                  <button
                    onClick={updateEvent}
                    className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
                  >
                    Speichern
                  </button>

                  <button
                    onClick={() => setEditingEvent(null)}
                    className="bg-slate-200 px-5 py-3 rounded-2xl"
                  >
                    Abbrechen
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MITARBEITER MODAL */}
        {showEmployeeModal && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
            <div className="bg-white rounded-3xl p-8 w-full max-w-md">
              <h3 className="text-3xl font-bold mb-6">Mitarbeiter</h3>

              <div className="space-y-4">
                <input
                  placeholder="Name"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEmployee({
                      ...newEmployee,
                      name: e.target.value,
                    })
                  }
                />

                <input
                  placeholder="Abteilung"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEmployee({
                      ...newEmployee,
                      department: e.target.value,
                    })
                  }
                />

                <input
                  placeholder="Urlaub"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEmployee({
                      ...newEmployee,
                      vacation: e.target.value,
                    })
                  }
                />

                <input
                  placeholder="ZA"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewEmployee({
                      ...newEmployee,
                      za: e.target.value,
                    })
                  }
                />

                <div className="flex gap-3">
                  <button
                    onClick={addEmployee}
                    className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
                  >
                    Speichern
                  </button>

                  <button
                    onClick={() => setShowEmployeeModal(false)}
                    className="bg-slate-200 px-5 py-3 rounded-2xl"
                  >
                    Abbrechen
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* URLAUB MODAL */}
        {showVacationModal && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
            <div className="bg-white rounded-3xl p-8 w-full max-w-md">
              <h3 className="text-3xl font-bold mb-6">Urlaub beantragen</h3>

              <div className="space-y-4">
                <select
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewRequest({
                      ...newRequest,
                      employee: e.target.value,
                    })
                  }
                >
                  <option>Mitarbeiter wählen</option>

                  {employees.map((employee) => (
                    <option key={employee.id}>{employee.name}</option>
                  ))}
                </select>

                <input
                  placeholder="Stunden"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewRequest({
                      ...newRequest,
                      hours: e.target.value,
                    })
                  }
                />

                <input
                  type="date"
                  className="w-full border rounded-2xl px-4 py-3"
                  onChange={(e) =>
                    setNewRequest({
                      ...newRequest,
                      date: e.target.value,
                    })
                  }
                />

                <div className="flex gap-3">
                  <button
                    onClick={addRequest}
                    className="bg-blue-600 text-white px-5 py-3 rounded-2xl"
                  >
                    Antrag senden
                  </button>

                  <button
                    onClick={() => setShowVacationModal(false)}
                    className="bg-slate-200 px-5 py-3 rounded-2xl"
                  >
                    Abbrechen
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
